def hello(event, context):
    if (event):
     print("welcome to terraform,evento recebido ", event)